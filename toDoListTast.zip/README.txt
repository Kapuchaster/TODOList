in Node console:

npm install
npm start
npm test